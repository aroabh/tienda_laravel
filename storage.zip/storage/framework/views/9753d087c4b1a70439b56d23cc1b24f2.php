<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Producto a editar')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-dots-darker bg-center bg-white dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white p-6">
        <?php if(Route::has('login')): ?>
            <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
                <?php if(auth()->guard()->check()): ?>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="container mx-auto mt-4 p-6 bg-white shadow-md rounded-lg">
            <form action="<?php echo e(route('productos.actualizar', $product->id)); ?>" method="post" class="space-y-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div>
                    <label for="name" class="block text-sm font-medium text-gray-600">Nombre:</label>
                    <input type="text" id="name" name="name" value="<?php echo e($product->name); ?>" class="mt-1 p-2 border rounded-md w-full" required>
                </div>

                <div>
                    <label for="description" class="block text-sm font-medium text-gray-600">Descripción:</label>
                    <textarea id="description" name="description" class="mt-1 p-2 border rounded-md w-full" required><?php echo e($product->description); ?></textarea>
                </div>

                <div>
                    <label for="price" class="block text-sm font-medium text-gray-600">Precio:</label>
                    <input type="number" id="price" name="price" step="0.01" value="<?php echo e($product->price); ?>" class="mt-1 p-2 border rounded-md w-full" required>
                </div>

                <div>
                    <label for="stock" class="block text-sm font-medium text-gray-600">Stock:</label>
                    <input type="number" id="stock" name="stock" value="<?php echo e($product->stock); ?>" class="mt-1 p-2 border rounded-md w-full" required>
                </div>

                <div>
                    <label for="image" class="block text-sm font-medium text-gray-600">Imagen:</label>
                    <input type="text" id="image" name="image" value="<?php echo e($product->image); ?>" class="mt-1 p-2 border rounded-md w-full" required>
                </div>

                <div>
                    <label for="category" class="block text-sm font-medium text-gray-600">Categoría:</label>
                    <select name="category" class="form-control mt-1 p-2 border rounded-md w-full" id="inputCategory">
                        <option value="Ordenadores" <?php echo e(old('category', $product->category) == 'Ordenadores' ? 'selected' : ''); ?>>Ordenadores</option>
                        <option value="Monitores" <?php echo e(old('category', $product->category) == 'Monitores' ? 'selected' : ''); ?>>Monitores</option>
                        <option value="Perifericos" <?php echo e(old('category', $product->category) == 'Perifericos' ? 'selected' : ''); ?>>Periféricos</option>
                        <option value="Componentes" <?php echo e(old('category', $product->category) == 'Componentes' ? 'selected' : ''); ?>>Componentes</option>
                        <option value="Consolas" <?php echo e(old('category', $product->category) == 'Consolas' ? 'selected' : ''); ?>>Consolas</option>
                    </select>

                </div>

                <div>
                    <button class="mybtn_purple" type="submit">Actualizar Producto</button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/almi/Escritorio/laravel/tienda/resources/views/tienda/editarproducto.blade.php ENDPATH**/ ?>
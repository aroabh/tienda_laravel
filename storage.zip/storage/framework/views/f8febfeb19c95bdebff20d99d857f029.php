<?php if(\Session::get("success")): ?>
    <div class="alert alert-success text-center">
        <p><?php echo e(\Session::get("success")); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH /home/almi/Escritorio/laravel/tienda/resources/views/partials/msg.blade.php ENDPATH**/ ?>
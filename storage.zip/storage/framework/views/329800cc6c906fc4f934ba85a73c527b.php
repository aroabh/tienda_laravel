<img width=110 src="<?php echo e(asset('/images/logopc.png')); ?>" alt="Logo de mi empresa">
<?php /**PATH /home/almi/Escritorio/laravel/tienda/resources/views/components/logo2.blade.php ENDPATH**/ ?>
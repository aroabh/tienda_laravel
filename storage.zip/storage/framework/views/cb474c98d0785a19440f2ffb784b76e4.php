<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight mb-6">
            <?php echo e(__('Tu carrito')); ?>

        </h2>
        <div>
            <?php if(session('success')): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                    <p class="font-bold">¡Éxito!</p>
                    <p><?php echo e(session('success')); ?></p>
                </div>
            <?php endif; ?>
        </div>
        <div class="relative sm:flex sm:justify-center  min-h-screen bg-dots-darker bg-center bg-white dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white">
            <?php if(Route::has('login')): ?>
                <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
                    <?php if(auth()->guard()->check()): ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>
                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="card">
                        <div class="card-body">
                            <?php if(Cart::count()): ?>
                                <table class="w-full border-collapse border border-gray-300 mt-8">
                                    <thead>
                                    <tr class="bg-gray-100">
                                        <th class="p-4 flex-shrink-0">ID</th>
                                        <th class="p-4">NOMBRE</th>
                                        <th class="p-4">CANTIDAD</th>
                                        <th class="p-4">PRECIO</th>
                                        <th class="p-4">IMPORTE</th>
                                        <th class="p-4">ELIMINAR</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="bg-white border-b text-center">
                                            <td class="p-4 flex-shrink-0 text-center">
                                                <img src="/images/<?php echo e($item->options->image); ?>" alt="Imagen" class="w-8 h-8 object-cover">
                                            </td>
                                            <td class="p-4"><?php echo e($item->name); ?></td>
                                            <td class="p-4"><?php echo e($item->qty); ?></td>
                                            <td class="p-4"><?php echo e(number_format($item->price, 2)); ?></td>
                                            <td class="p-4"><?php echo e(number_format($item->qty * $item->price, 2)); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('removeitem')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="rowId" value="<?php echo e($item->rowId); ?>">
                                                    <input type="submit" name="btn" class="mybtn_red" value="X">
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="fw-bolder">
                                        <td colspan="3"></td>
                                        <td class="text-end">SUBTOTAL:</td>
                                        <td class="text-end"><?php echo e(Cart::subtotal()); ?></td>
                                    </tr>
                                    <tr class="fw-bolder">
                                        <td colspan="3"></td>
                                        <td class="text-end">IVA:</td>
                                        <td class="text-end"><?php echo e(Cart::tax()); ?></td>
                                    </tr>
                                    <tr class="fw-bolder">
                                        <td colspan="3"></td>
                                        <td class="text-end">TOTAL:</td>
                                        <td class="text-end"><?php echo e(Cart::total()); ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                                <div class="card-footer mt-4 flex items-center justify-center">
                                    <form action="<?php echo e(route('clear')); ?>" method="get">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="mybtn_purple px-4 py-2">Tramitar Pedido</button>
                                    </form>
                                </div>

                            <?php else: ?>
                                <a href="/" class="text-center mybtn_purple mt-10">Tu carrito está vacío. Agrega un producto</a>
                            <?php endif; ?>

                        </div>
                    </div>

                </div>


            </div>
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/almi/Escritorio/laravel/tienda/resources/views/cart/checkout.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Subir nuevo producto a tienda')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-dots-darker bg-center bg-white dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white p-6">
        <?php if(Route::has('login')): ?>
            <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
                <?php if(auth()->guard()->check()): ?>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

            <!-- En anadirproducto.blade.php -->
            <?php if(session('success')): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                    <p class="font-bold">¡Éxito!</p>
                    <p><?php echo e(session('success')); ?></p>
                </div>
            <?php endif; ?>

            <!-- Resto del código del formulario -->


            <div class="container mx-auto p-8 bg-white dark:bg-gray-800 shadow-md rounded-lg">
            <form action="<?php echo e(route('anadir.agregar')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Nombre:</label>
                    <input type="text" id="name" name="name" required class="w-full p-2 border border-gray-300 rounded">
                </div>
                <div class="mb-4">
                    <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Descripción:</label>
                    <textarea id="description" name="description" required class="w-full p-2 border border-gray-300 rounded"></textarea>
                </div>
                <div class="mb-4">
                    <label for="price" class="block text-gray-700 text-sm font-bold mb-2">Precio:</label>
                    <input type="number" id="price" name="price" min="0" step="0.01" required class="w-full p-2 border border-gray-300 rounded">
                </div>
                <div class="mb-4">
                    <label for="stock" class="block text-gray-700 text-sm font-bold mb-2">Stock:</label>
                    <input type="number" id="stock" name="stock" min="0" required class="w-full p-2 border border-gray-300 rounded">
                </div>
                <div class="mb-4">
                    <label for="image" class="block text-gray-700 text-sm font-bold mb-2">Imagen:</label>
                    <input type="text" id="image" name="image" required class="w-full p-2 border border-gray-300 rounded">
                </div>
                <div class="mb-4">
                    <label for="category" class="block text-gray-700 text-sm font-bold mb-2">Categoría:</label>
                    <select name="category" class="w-full p-2 border border-gray-300 rounded">
                        <option value="Ordenadores" <?php echo e(request()->input('category') == 'Ordenadores' ? 'selected' : ''); ?>>Ordenadores</option>
                        <option value="Monitores" <?php echo e(request()->input('category') == 'Monitores' ? 'selected' : ''); ?>>Monitores</option>
                        <option value="Perifericos" <?php echo e(request()->input('category') == 'Perifericos' ? 'selected' : ''); ?>>Periféricos</option>
                        <option value="Componentes" <?php echo e(request()->input('category') == 'Componentes' ? 'selected' : ''); ?>>Componentes</option>
                        <option value="Consolas" <?php echo e(request()->input('category') == 'Consolas' ? 'selected' : ''); ?>>Consolas</option>
                    </select>
                </div>
                <button class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700" type="submit">Guardar Producto</button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/almi/Escritorio/laravel/tienda/resources/views/tienda/anadirproducto.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Productos nuevos disponibles')); ?>

        </h2>
        <div class="container">
            <!-- Mensaje de éxito -->
            <?php if(session('success')): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                    <p class="font-bold">¡Éxito!</p>
                    <p><?php echo e(session('success')); ?></p>
                </div>
            <?php endif; ?>
        </div>
        <div name="div1" class="category">
            <form action="<?php echo e(route('productos.mostrar')); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="category" value="<?php echo e(request()->input('category')); ?>">
                <div class="category">
                    <label for="inputCategory" class="form-label">Categoria</label>
                    <select name="category" class="form-control" id="inputCategory">
                        <option value="todo" <?php echo e(request()->input('category') == 'todo' ? 'selected' : ''); ?>>Todo</option>
                        <option value="Ordenadores" <?php echo e(request()->input('category') == 'Ordenadores' ? 'selected' : ''); ?>>Ordenadores</option>
                        <option value="Monitores" <?php echo e(request()->input('category') == 'Monitores' ? 'selected' : ''); ?>>Monitores</option>
                        <option value="Perifericos" <?php echo e(request()->input('category') == 'Perifericos' ? 'selected' : ''); ?>>Periféricos</option>
                        <option value="Componentes" <?php echo e(request()->input('category') == 'Componentes' ? 'selected' : ''); ?>>Componentes</option>
                        <option value="Consolas" <?php echo e(request()->input('category') == 'Consolas' ? 'selected' : ''); ?>>Consolas</option>
                    </select>
                </div>
                <div class="category">
                    <button id="btnMostrar" class="mybtn_blue">Mostrar</button>
                    <button type="button" onclick="window.location.href='<?php echo e(route('resetear.categoria')); ?>'" class="mybtn_red">
                        Resetear
                    </button>
                </div>
            </form>
        </div>
        <div name="div2" class="relative sm:flex sm:justify-center sm:items-center min-h-screen bg-dots-darker bg-center bg-white !important dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white">
            <?php if(Route::has('login')): ?>
                <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
                    <?php if(auth()->guard()->check()): ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>
                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="container">
                <div class="grid grid-cols-3 gap-6 justify-content-center">

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border p-3 mt-3 text-center">
                            <div class="card">
                                <img src="/images/<?php echo e($item->image); ?>" class="w-200 rounded-lg mx-auto">
                                <div class="card-body text-center">
                                    <h2><?php echo e($item->name); ?></h2>
                                    <h2><?php echo e($item->description); ?></h2>
                                    <h2>€ <?php echo e($item->price); ?></h2>
                                    <h2><?php echo e($item->category); ?></h2>
                                </div>
                                <div class="card-footer mt-4 flex items-center justify-center">
                                    <form action="<?php echo e(route('add')); ?>" method="post" class="flex items-center space-x-4">
                                        <?php echo csrf_field(); ?>
                                        <?php if(auth()->guard()->check()): ?>
                                            <?php if(@Auth::user()->hasRole('Admin')): ?>
                                                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                                <button type="button" class="mybtn_blue px-4 py-2" onclick="window.location.href='<?php echo e(route('productos.editar', $item->id)); ?>'">Editar</button>
                                                <a href="<?php echo e(route('productos.borrar', $item->id)); ?>" class="mybtn_red" onclick="return confirm('¿Estás seguro de que quieres borrar este producto?')">Borrar</a>                                                <?php endif; ?>
                                        <?php endif; ?>

                                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                        <input type="submit" name="btn" class="mybtn_purple px-4 py-2" value="Añadir al carrito">
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/almi/Escritorio/laravel/tienda/resources/views/tienda/nuevo.blade.php ENDPATH**/ ?>